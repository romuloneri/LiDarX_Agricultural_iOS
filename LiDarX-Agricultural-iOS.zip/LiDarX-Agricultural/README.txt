
LiDarX Agricultural — iOS (SwiftUI + WKWebView)

Como usar no Codemagic:
1) Faça login no https://codemagic.io/ e escolha "Add URL manually".
2) Faça upload deste ZIP do projeto.
3) Quando solicitado, conecte sua conta Apple Developer.
4) Inicie o build "iOS app" e selecione distribuição via TestFlight.
5) O build aparecerá no App Store Connect (aba TestFlight).

Bundle ID: com.lidarx.agricultural
URL carregada: https://www.lidarx.com.br

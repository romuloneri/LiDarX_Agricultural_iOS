import SwiftUI

@main
struct LiDarXApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}